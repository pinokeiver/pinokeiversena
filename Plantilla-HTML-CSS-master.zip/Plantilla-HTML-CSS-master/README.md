![N|Solid](https://eduardosantos.site/wp-content/uploads/2019/01/EDUARDO-BLOG-e1546914705377.png)

# Pagina web en html y css para principiantes

Plantilla para modificar según conocimientos adquiridos en html y css. Incluye librería bootstrap. 

![N|Solid](https://cldup.com/dTxpPi9lDf.thumb.png)
